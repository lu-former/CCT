# models/CCT.py
import torch
import torch.nn as nn
import math


class Patch_Embedding(nn.Module):
    def __init__(self, seq_len, patch_num, patch_len, d_model, d_ff, variate_num):
        super(Patch_Embedding, self).__init__()
        self.pad_num = patch_num * patch_len - seq_len
        self.patch_len = patch_len
        self.linear = nn.Sequential(nn.LayerNorm([variate_num, patch_num, patch_len]), nn.Linear(patch_len, d_ff),
                                    nn.GELU(), nn.Linear(d_ff, d_model),
                                    nn.LayerNorm([variate_num, patch_num, d_model]))

    def forward(self, x):
        x = nn.functional.pad(x, (0, self.pad_num))
        x = x.unfold(2, self.patch_len, self.patch_len)
        return self.linear(x)


class De_Patch_Embedding(nn.Module):
    def __init__(self, pred_len, patch_num, d_model, d_ff, variate_num):
        super(De_Patch_Embedding, self).__init__()
        self.linear = nn.Sequential(nn.Flatten(2), nn.Linear(patch_num * d_model, d_ff), nn.GELU(), nn.Dropout(0.1),
                                    nn.Linear(d_ff, pred_len))

    def forward(self, x):
        return self.linear(x)


class Simple_CT_MSA(nn.Module):
    def __init__(self, dim, heads, dropout):
        super(Simple_CT_MSA, self).__init__()
        self.norm = nn.LayerNorm(dim)
        self.attention = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        batch, dim, variate, patches = x.shape
        x_reshaped = x.permute(0, 2, 3, 1).reshape(batch * variate, patches, dim)
        x_norm = self.norm(x_reshaped)
        attn_out, _ = self.attention(x_norm, x_norm, x_norm)
        x_reshaped = x_reshaped + self.dropout(attn_out)
        x_out = x_reshaped.reshape(batch, variate, patches, dim).permute(0, 3, 1, 2)
        return x_out


class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()
        self.task_name = configs.task_name
        self.ms = configs.features == 'MS'
        self.EPS = 1e-5
        patch_len = configs.patch_len
        patch_num = math.ceil(configs.seq_len / patch_len)
        variate_num = 1 if self.ms else configs.dec_in
        self.alpha = nn.Parameter(torch.ones([1]) * 0.7)
        self.beta = nn.Parameter(torch.ones([1]) * 0.7)
        self.correlation_embedding = nn.Conv1d(configs.dec_in, variate_num, 3, padding='same')
        self.value_embedding = Patch_Embedding(configs.seq_len, patch_num, patch_len, configs.d_model, configs.d_ff,
                                               variate_num)
        self.pos_embedding = nn.Parameter(torch.randn(1, variate_num, patch_num, configs.d_model))
        # 简化的注意力模块 - 只用1层
        self.temporal_module = Simple_CT_MSA(dim=configs.d_model, heads=4, dropout=0.1)
        # 修复卷积层 - 使用2D卷积处理patch维度
        self.trend_conv = nn.Conv2d(configs.d_model, configs.d_model, (3, 3), padding=(1, 1), groups=configs.d_model)
        if self.task_name == 'long_term_forecast' or self.task_name == 'short_term_forecast':
            self.head = De_Patch_Embedding(configs.pred_len, patch_num, configs.d_model, configs.d_ff, variate_num)
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.xavier_uniform_(module.weight)
            if module.bias is not None: torch.nn.init.constant_(module.bias, 0)
        elif isinstance(module, nn.LayerNorm):
            torch.nn.init.constant_(module.bias, 0)
            torch.nn.init.constant_(module.weight, 1.0)

    def forecast(self, x_enc):
        x_enc = x_enc.permute(0, 2, 1)
        if self.ms:
            x_obj = x_enc[:, [-1], :]
            mean = torch.mean(x_obj, dim=-1, keepdim=True)
            std = torch.std(x_obj, dim=-1, keepdim=True)
            x_enc_normalized = (x_enc - torch.mean(x_enc, dim=-1, keepdim=True)) / (
                        torch.std(x_enc, dim=-1, keepdim=True) + self.EPS)
        else:
            mean = torch.mean(x_enc, dim=-1, keepdim=True)
            std = torch.std(x_enc, dim=-1, keepdim=True)
            x_enc_normalized = (x_enc - mean) / (std + self.EPS)
        x_obj = x_enc_normalized[:, [-1], :] if self.ms else x_enc_normalized
        x_obj = self.alpha * x_obj + (1 - self.alpha) * self.correlation_embedding(x_enc_normalized)
        x_embedded = self.beta * self.value_embedding(x_obj) + (1 - self.beta) * self.pos_embedding

        # 简化的特征提取
        x_temporal = self.temporal_module(x_embedded.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)

        # 修复的趋势提取 - 使用2D卷积
        x_trend = self.trend_conv(x_embedded.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)

        # 更温和的融合
        x_final = x_embedded + 0.05 * (x_temporal + x_trend)

        y_out = self.head(x_final)
        y_out = y_out * std + mean
        return y_out.permute(0, 2, 1)

    def imputation(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        return self.forecast(x_enc)

    def anomaly_detection(self, x_enc):
        return self.forecast(x_enc)

    def classification(self, x_enc, x_mark_enc):
        return torch.randn(x_enc.shape[0], 1)

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name in ['long_term_forecast', 'short_term_forecast']:
            return self.forecast(x_enc)
        elif self.task_name == 'imputation':
            return self.imputation(x_enc, x_mark_enc, x_dec, x_mark_dec, mask)
        elif self.task_name == 'anomaly_detection':
            return self.anomaly_detection(x_enc)
        elif self.task_name == 'classification':
            return self.classification(x_enc, x_mark_enc)
        else:
            raise ValueError(f"Unsupported task: {self.task_name}")



# # models/CCT.py
# import torch
# import torch.nn as nn
# import math
#
# class Patch_Embedding(nn.Module):
#     def __init__(self, seq_len, patch_num, patch_len, d_model, d_ff, variate_num):
#         super(Patch_Embedding, self).__init__()
#         self.pad_num = patch_num * patch_len - seq_len
#         self.patch_len = patch_len
#         self.linear = nn.Sequential(
#             nn.LayerNorm([variate_num, patch_num, patch_len]),
#             nn.Linear(patch_len, d_ff),
#             nn.LayerNorm([variate_num, patch_num, d_ff]),
#             nn.ReLU(),
#             nn.Linear(d_ff, d_model),
#             nn.LayerNorm([variate_num, patch_num, d_model]),
#             nn.ReLU())
#
#     def forward(self, x):
#         x = nn.functional.pad(x, (0, self.pad_num))
#         x = x.unfold(2, self.patch_len, self.patch_len)
#         x = self.linear(x)
#         return x
#
# class De_Patch_Embedding(nn.Module):
#     def __init__(self, pred_len, patch_num, d_model, d_ff, variate_num):
#         super(De_Patch_Embedding, self).__init__()
#         self.linear = nn.Sequential(
#             nn.Flatten(2),
#             nn.Linear(patch_num * d_model, d_ff),
#             nn.LayerNorm([variate_num, d_ff]),
#             nn.ReLU(),
#             nn.Linear(d_ff, pred_len))
#
#     def forward(self, x):
#         x = self.linear(x)
#         return x
#
# class CT_MSA(nn.Module):
#     def __init__(self, dim, depth, heads, window_size, mlp_dim, num_time, dropout, device):
#         super(CT_MSA, self).__init__()
#         self.norm = nn.LayerNorm(dim)
#         self.attention = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
#         self.mlp = nn.Sequential(
#             nn.Linear(dim, mlp_dim),
#             nn.ReLU(),
#             nn.Dropout(dropout),
#             nn.Linear(mlp_dim, dim),
#             nn.Dropout(dropout)
#         )
#
#     def forward(self, x):
#         batch, dim, variate, patches = x.shape
#         x_reshaped = x.permute(0, 2, 3, 1).reshape(batch * variate, patches, dim)
#         x_norm = self.norm(x_reshaped)
#         attn_out, _ = self.attention(x_norm, x_norm, x_norm)
#         x_reshaped = x_reshaped + attn_out
#         x_mlp = self.mlp(self.norm(x_reshaped))
#         x_reshaped = x_reshaped + x_mlp
#         x_out = x_reshaped.reshape(batch, variate, patches, dim).permute(0, 3, 1, 2)
#         return x_out
#
#
# class Trend_aware_attention(nn.Module):
#     def __init__(self, K, d_in, d_out, kernel_size=3):
#         super(Trend_aware_attention, self).__init__()
#         self.K = K
#         self.d_in = d_in
#         self.d_out = d_out
#
#         self.proj_down = nn.Linear(d_in, d_out)
#         self.conv = nn.Conv1d(
#             in_channels=d_out,
#             out_channels=d_out,
#             kernel_size=kernel_size,
#             padding=kernel_size // 2,
#             groups=d_out  # 深度卷积，可选；也可去掉 groups=d_out 用普通卷积
#         )
#         self.proj_up = nn.Linear(d_out, d_in)
#
#     def forward(self, x):
#         B, T, N, D = x.shape  # (batch, time, variate, d_in)
#
#         # 降维
#         x_proj = self.proj_down(x)  # (B, T, N, d_out)
#
#         # 转换为 Conv1d 格式: (B*N, d_out, T)
#         x_reshaped = x_proj.permute(0, 2, 1, 3).reshape(B * N, T, self.d_out)
#         x_reshaped = x_reshaped.permute(0, 2, 1)  # (B*N, d_out, T)
#
#         # 卷积提取趋势
#         x_trend = self.conv(x_reshaped)  # (B*N, d_out, T)
#
#         # 恢复形状
#         x_trend = x_trend.permute(0, 2, 1).reshape(B, N, T, self.d_out)
#         x_trend = x_trend.permute(0, 2, 1, 3)  # (B, T, N, d_out)
#
#         # 升维回原始维度
#         x_trend = self.proj_up(x_trend)  # (B, T, N, d_in)
#
#         return x_trend
#
# # 主模型类 - 按照框架要求的结构
# class Model(nn.Module):
#     def __init__(self, configs):
#         super(Model, self).__init__()
#         self.task_name = configs.task_name
#         self.ms = configs.features == 'MS'
#         self.EPS = 1e-5
#
#         # 基础模型参数
#         patch_len = configs.patch_len
#         patch_num = math.ceil(configs.seq_len / patch_len)
#         variate_num = 1 if self.ms else configs.dec_in
#
#         # 基础嵌入层
#         self.alpha = nn.Parameter(torch.ones([1]) * configs.alpha)
#         self.beta = nn.Parameter(torch.ones([1]) * configs.beta)
#         self.correlation_embedding = nn.Conv1d(configs.dec_in, variate_num, 3, padding='same')
#         self.value_embedding = Patch_Embedding(configs.seq_len, patch_num, patch_len, configs.d_model, configs.d_ff,
#                                               variate_num)
#         self.pos_embedding = nn.Parameter(torch.randn(1, variate_num, patch_num, configs.d_model))
#
#         # === 模块缝合区域 ===
#         self.ct_msa_blocks = getattr(configs, 'ct_msa_blocks', 3)
#         self.ct_msa_heads = getattr(configs, 'ct_msa_heads', 8)
#         self.ct_msa_mlp_dim = getattr(configs, 'ct_msa_mlp_dim', configs.d_model * 2)
#
#         self.trend_heads = getattr(configs, 'trend_heads', 8)
#         self.trend_d = getattr(configs, 'trend_d', configs.d_model // 8)
#         self.trend_kernel_size = getattr(configs, 'trend_kernel_size', 3)
#
#         # 创建CT_MSA模块
#         self.t_modules = nn.ModuleList()
#         for b in range(self.ct_msa_blocks):
#             window_size = patch_num // 2 ** (self.ct_msa_blocks - b - 1)
#             self.t_modules.append(
#                 CT_MSA(dim=configs.d_model,
#                       depth=1,
#                       heads=self.ct_msa_heads,
#                       window_size=window_size,
#                       mlp_dim=self.ct_msa_mlp_dim,
#                       num_time=patch_num,
#                       dropout=getattr(configs, 'dropout', 0.1),
#                       device=torch.device("cuda:0" if torch.cuda.is_available() else "cpu"))
#             )
#
#         # 创建Trend_aware_attention模块
#         self.trend_attention = Trend_aware_attention(
#             K=self.trend_heads,
#             d_in=configs.d_model,  # 输入维度：128
#             d_out=self.trend_d,  # 内部处理维度：16（因为 128//8）
#             kernel_size=self.trend_kernel_size
#         )
#         # 特征融合门控机制
#         self.fusion_gate = nn.Sequential(
#             nn.Linear(configs.d_model * 2, configs.d_model),
#             nn.Sigmoid()
#         )
#
#         # 输出头
#         if self.task_name == 'long_term_forecast' or self.task_name == 'short_term_forecast':
#             self.head = De_Patch_Embedding(
#                 configs.pred_len, patch_num, configs.d_model, configs.d_ff, variate_num)
#
#     def apply_temporal_modules(self, x):
#         x_reshaped = x.permute(0, 3, 1, 2)
#         for i in range(self.ct_msa_blocks):
#             x_reshaped = self.t_modules[i](x_reshaped)
#         x_temporal = x_reshaped.permute(0, 2, 3, 1)
#         return x_temporal
#
#     def apply_trend_attention(self, x):
#         x_reshaped = x.permute(0, 2, 1, 3)
#         x_trend = self.trend_attention(x_reshaped)
#         x_trend = x_trend.permute(0, 2, 1, 3)
#         return x_trend
#
#     def forecast(self, x_enc):
#         x_enc = x_enc.permute(0, 2, 1)
#         if self.ms:
#             x_obj = x_enc[:, [-1], :]
#             mean = torch.mean(x_obj, dim=-1, keepdim=True)
#             std = torch.std(x_obj, dim=-1, keepdim=True)
#             x_enc_normalized = (x_enc - torch.mean(x_enc, dim=-1, keepdim=True)) / (torch.std(x_enc, dim=-1, keepdim=True) + self.EPS)
#         else:
#             mean = torch.mean(x_enc, dim=-1, keepdim=True)
#             std = torch.std(x_enc, dim=-1, keepdim=True)
#             x_enc_normalized = (x_enc - mean) / (std + self.EPS)
#
#         x_obj = x_enc_normalized[:, [-1], :] if self.ms else x_enc_normalized
#         x_obj = self.alpha * x_obj + (1 - self.alpha) * self.correlation_embedding(x_enc_normalized)
#         x_embedded = self.beta * self.value_embedding(x_obj) + (1 - self.beta) * self.pos_embedding
#
#         x_temporal = self.apply_temporal_modules(x_embedded)
#         x_trend = self.apply_trend_attention(x_embedded)
#
#         fusion_input = torch.cat([x_temporal, x_trend], dim=-1)
#         gate_weights = self.fusion_gate(fusion_input)
#         x_fused = gate_weights * x_temporal + (1 - gate_weights) * x_trend
#         x_final = x_embedded + 0.3 * x_fused
#
#         y_out = self.head(x_final)
#         y_out = y_out * std + mean
#         y_out = y_out.permute(0, 2, 1)
#         return y_out
#
#     def imputation(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
#         return self.forecast(x_enc)
#
#     def anomaly_detection(self, x_enc):
#         return self.forecast(x_enc)
#
#     def classification(self, x_enc, x_mark_enc):
#         batch_size = x_enc.shape[0]
#         return torch.randn(batch_size, 1)
#
#     def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
#         if self.task_name == 'long_term_forecast' or self.task_name == 'short_term_forecast':
#             dec_out = self.forecast(x_enc)
#         elif self.task_name == 'imputation':
#             dec_out = self.imputation(x_enc, x_mark_enc, x_dec, x_mark_dec, mask)
#         elif self.task_name == 'anomaly_detection':
#             dec_out = self.anomaly_detection(x_enc)
#         elif self.task_name == 'classification':
#             dec_out = self.classification(x_enc, x_mark_enc)
#         else:
#             raise ValueError(f"Unsupported task: {self.task_name}")
#         return dec_out