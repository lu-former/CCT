import os
import torch
from models import Autoformer, Transformer, TimesNet, Nonstationary_Transformer, DLinear, FEDformer, \
    Informer, LightTS, Reformer, ETSformer, Pyraformer, PatchTST, MICN, Crossformer, FiLM, iTransformer, \
    Koopa, TiDE, FreTS, TimeMixer, TSMixer, SegRNN, MambaSimple, TemporalFusionTransformer, SCINet, PAttn, TimeXer, \
    CrossLinear

# 修改CCT模型的导入方式
try:
    # 从 models.CCT 导入 Model 类
    from models.CCT import Model as CCT_Model
    CCT_imported = True
    # print("CCT model imported successfully")
except ImportError as e:
    # print(f"Warning: Could not import CCT model: {e}")
    # print("Please make sure models/CCT.py exists and contains the CCT model")
    CCT_imported = False

    # 创建一个空的CCT类作为占位符
    class CCT_Model(torch.nn.Module):
        def __init__(self, configs):
            super().__init__()
            raise ImportError("CCT model not found. Please check models/CCT.py file exists and contains the CCT model implementation.")


class Exp_Basic(object):
    def __init__(self, args):
        self.args = args
        self.model_dict = {
            'CrossLinear': CrossLinear,
            'TimesNet': TimesNet,
            'Autoformer': Autoformer,
            'Transformer': Transformer,
            'Nonstationary_Transformer': Nonstationary_Transformer,
            'DLinear': DLinear,
            'FEDformer': FEDformer,
            'Informer': Informer,
            'LightTS': LightTS,
            'Reformer': Reformer,
            'ETSformer': ETSformer,
            'PatchTST': PatchTST,
            'Pyraformer': Pyraformer,
            'MICN': MICN,
            'Crossformer': Crossformer,
            'FiLM': FiLM,
            'iTransformer': iTransformer,
            'Koopa': Koopa,
            'TiDE': TiDE,
            'FreTS': FreTS,
            'MambaSimple': MambaSimple,
            'TimeMixer': TimeMixer,
            'TSMixer': TSMixer,
            'SegRNN': SegRNN,
            'TemporalFusionTransformer': TemporalFusionTransformer,
            "SCINet": SCINet,
            'PAttn': PAttn,
            'TimeXer': TimeXer
        }

        # 只有在成功导入CCT时才添加到模型字典
        if CCT_imported:
            # 直接使用导入的模型类
            self.model_dict['CCT'] = CCT_Model
            print("CCT model added to model dictionary")
        else:
            print("CCT model not available in model dictionary")

        if args.model == 'Mamba':
            print('Please make sure you have successfully installed mamba_ssm')
            from models import Mamba
            self.model_dict['Mamba'] = Mamba

        self.device = self._acquire_device()
        self.model = self._build_model().to(self.device)

    def _build_model(self):
        raise NotImplementedError

    def _acquire_device(self):
        if self.args.use_gpu:
            os.environ["CUDA_VISIBLE_DEVICES"] = str(
                self.args.gpu) if not self.args.use_multi_gpu else self.args.devices
            device = torch.device('cuda:{}'.format(self.args.gpu))
            print('Use GPU: cuda:{}'.format(self.args.gpu))
        else:
            device = torch.device('cpu')
            print('Use CPU')
        return device

    def _get_data(self):
        pass

    def vali(self):
        pass

    def train(self):
        pass

    def test(self):
        pass