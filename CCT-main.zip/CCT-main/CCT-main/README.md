# CCT

Official implementation of **"[The CCT Model for Single-Day Land Surface Temperature Prediction Based on Multidimensional Data]()"** (*under review*).

> *Note: This repository contains the code for the CCT model proposed in the manuscript submitted to the journal. The paper is currently under revision. A preprint/DOI will be added once available.*

## Overview

CCT is a deep learning model designed for single-day land surface temperature (LST) prediction by integrating multidimensional data. The model leverages cross-correlation embedding and transformer-like architecture to capture complex spatiotemporal dependencies among meteorological variables and LST.

## Usage

1. **Install dependencies**  
   Python 3.8 or later is recommended. First, clone this repository and install the required packages:

   ```bash
   git clone https://github.com/lu-former/CCT.git
   cd CCT
   pip install -r requirements.txt